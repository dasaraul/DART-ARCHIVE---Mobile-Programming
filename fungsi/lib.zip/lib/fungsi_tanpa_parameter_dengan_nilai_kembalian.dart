void main() {
  double avgnilai = nilaiMinimal();
  print('Rata-rata nilai: $avgnilai');
}

double nilaiMinimal() {
  double Tugas1 = 95.1;
  double Tugas2 = 82.7;

  return (Tugas1 + Tugas2) / 2;
}
