void main() {
  dataMhs();
}

void dataMhs() {
  String nama = 'Muhammad Akbar';
  String npm = '237006516058';
  String prodi = 'Sistem Informasi';
  print('Nama Lengkap : $nama');
  print('NPM          : $npm');
  print('Program Studi: $prodi');
}