void main() {
  String nick = 'Muhammad';
  String mid = 'Akbar';
  BioMhs(nick, mid);
}

void BioMhs(String nick, String mid) {
  String full = 'Nama: $nick $mid';
  print(full);
}
